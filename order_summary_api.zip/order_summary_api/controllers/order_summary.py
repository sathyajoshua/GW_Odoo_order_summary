from odoo import http
from odoo.http import request, Response
import json

from ..utils.jwt_utils import verify_jwt_token

class OrderSummaryAPI(http.Controller):

    @http.route(['/api/v1/order-summary'], type='http', auth='public', methods=['GET'], csrf=False, cors='*')
    def order_summary(self, **kwargs):
        # ---- JWT AUTH ----
        auth_header = request.httprequest.headers.get('Authorization', '')
        token = auth_header.replace('Bearer ', '') if auth_header.startswith('Bearer ') else None
        if not token or not verify_jwt_token(token):
            return Response(json.dumps({"error": "Unauthorized"}), status=401, content_type='application/json')

        # ---- FILTERS ----
        delivery_ids = kwargs.get('delivery_ids')
        ptmpls = kwargs.get('product_templates')
        try:
            delivery_ids = [int(x) for x in delivery_ids.split(',')] if delivery_ids else []
        except Exception:
            delivery_ids = []
        try:
            ptmpls = [int(x) for x in ptmpls.split(',')] if ptmpls else []
        except Exception:
            ptmpls = []

        env = request.env
        domain = []

        if ptmpls:
            domain += [('product_id.product_tmpl_id', 'in', ptmpls)]

        # ---- OPTIMIZED AGGREGATION ----
        fields = ['product_id', 'product_uom_qty:sum', 'qty_delivered:sum', 'price_total:sum']
        groupby = ['product_id']

        summary = env['sale.order.line'].read_group(
            domain=domain,
            fields=fields,
            groupby=groupby,
        )

        # Format for popup table expected in the assessment
        rows = []
        for rec in summary:
            product = env['product.product'].browse(rec['product_id'][0])
            rows.append({
                "product_id": rec['product_id'][0],
                "product_name": product.display_name,
                "sold_qty": rec.get('product_uom_qty_sum', 0.0),
                "delivered_qty": rec.get('qty_delivered_sum', 0.0),
                "revenue": rec.get('price_total_sum', 0.0),
            })

        payload = {
            "filters": {"delivery_ids": delivery_ids, "product_templates": ptmpls},
            "rows": rows,
            "totals": {
                "sold_qty": sum(r["sold_qty"] for r in rows),
                "delivered_qty": sum(r["delivered_qty"] for r in rows),
                "revenue": sum(r["revenue"] for r in rows),
            }
        }
        return Response(json.dumps(payload, default=str), status=200, content_type='application/json')
