import base64, json, hmac, hashlib, time

SECRET = "CHANGE_ME_TO_A_SECURE_SECRET"  

def _b64url_decode(s):
    s = s + '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)

def verify_jwt_token(token: str) -> bool:
    try:
        header_b64, payload_b64, signature_b64 = token.split('.')
        signing_input = f"{header_b64}.{payload_b64}".encode()
        expected_sig = hmac.new(SECRET.encode(), signing_input, hashlib.sha256).digest()
        expected_b64 = base64.urlsafe_b64encode(expected_sig).rstrip(b"=").decode()
        if not hmac.compare_digest(expected_b64, signature_b64):
            return False

        payload = json.loads(_b64url_decode(payload_b64))
        exp = payload.get("exp")
        if exp and time.time() > exp:
            return False
        return True
    except Exception:
        return False
