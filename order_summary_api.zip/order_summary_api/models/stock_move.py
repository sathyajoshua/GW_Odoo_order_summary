from odoo import models, api

class StockMoveBusNotify(models.Model):
    _inherit = "stock.move"

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        self._notify_order_summary()
        return records

    def write(self, vals):
        res = super().write(vals)
        self._notify_order_summary()
        return res

    def _notify_order_summary(self):
        bus = self.env['bus.bus']
        payload = {"event": "stock_changed"}
        channel = (self._cr.dbname, "order_summary_channel")
        bus.sendone(channel, payload)
